class CameraError(Exception):
    pass
